<script>
export default {

}
</script>

<template>
  <Headerkoa/>
  <div class=" flex flex-col text-center px-2 ">
      <p class="text-3xl p-10 text-red-600">Quiénes somos</p>
      <p> CandyKoa es una web Española, creada para hacer felices a niños (y no tan niños), llevando a sus hogares
        chucherías de diversas partes del mundo. <br>
        Con nuestra web deseamos acercarles un poco más hacia la cultura de países como Japón, México o EEUU. <br>
        El equipo encargado de hacer la web son alumnos de la Escuela de Organización Industrial (EOI), bootcamp de
        Programación FrontEnd, dirigido por el Sr. Jose Román (Manz). <br>
        El equipo corporativo de CandyKoa desea que disfruten de nuestras chucherías.
      </p>
    </div>
    <div class="flex flex-row  p-10">

      <div class="w-30 hover:scale-125 transition duration-100 ease-in-out">
        <a href="https://www.linkedin.com/in/mar%C3%ADa-mira-alav%C3%A9s/" target="_blank"><img
            src="assets/compis/MaríaKoa.png" alt="Maria"></a>
      </div>
      <div class="w-30 hover:scale-125 transition duration-100 ease-in-out">
        <a href="https://www.linkedin.com/in/jorge-porta-blanco-399670199/" target="_blank"><img
            src="assets/compis/JorgeKoa.png" alt="Jorge"></a>
      </div>
      <div class="w-30 hover:scale-125 transition duration-100 ease-in-out">
        <a href="https://www.linkedin.com/in/celia-taroncher/" target="_blank"><img src="assets/compis/CeliaKoa.png"
            alt="Celia"></a>
      </div>
      <div class="w-30 hover:scale-125 transition duration-100 ease-in-out">
        <a href="https://www.linkedin.com/in/miriam-alonso-hernandez-186299267/" target="_blank"><img
            src="assets/compis/MiriamKoa.png" alt="Miriam"></a>
      </div>
      <div class="esther hover:scale-125  transition duration-100 ease-in-out">
        <a href="https://www.linkedin.com/in/estherdiazdelaguardia/" target="_blank"><img
            src="assets/compis/EstherKoa.png" alt="Esther"></a>
      </div>
    </div>
    <Footerkoa/>
</template>
